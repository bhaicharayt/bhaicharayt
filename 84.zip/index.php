<?php
header("Location: ./84/");
exit();
?>