<?php
$name = 'MARK OP';

$emailku = 'drmarkpubg@gmail.com';
?>